import updatedFetch from './fetch';
// @ts-ignore
global.fetch = updatedFetch;
